# qesdk
Quantease's securities data query system and backtest/simulation/trade system for a quant's strategy algorithm.
